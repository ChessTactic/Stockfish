/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2015 Marco Costalba, Joona Kiiski, Tord Romstad
  Copyright (C) 2015-2018 Marco Costalba, Joona Kiiski, Gary Linscott, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <algorithm>
#include <cassert>
#include <cstddef> // For offsetof()
#include <cstring> // For std::memset, std::memcmp
#include <iomanip>
#include <sstream>

#include "bitboard.h"
#include "misc.h"
#include "movegen.h"
#include "position.h"
#include "thread.h"
#include "tt.h"
#include "uci.h"
#include "syzygy/tbprobe.h"

using std::string;

namespace PSQT {
  extern Score psq[PIECE_NB][SQUARE_NB];
}

namespace Zobrist {

  Key psq[PIECE_NB][SQUARE_NB];
  Key enpassant[FILE_NB];
  Key castling[CASTLING_RIGHT_NB];
  Key side, noPawns;
}

namespace {

const string PieceToChar(" PNBRQK  pnbrqk");

const Piece Pieces[] = { W_PAWN, W_KNIGHT, W_BISHOP, W_ROOK, W_QUEEN, W_KING,
                         B_PAWN, B_KNIGHT, B_BISHOP, B_ROOK, B_QUEEN, B_KING };

// min_attacker() is a helper function used by see_ge() to locate the least
// valuable attacker for the side to move, remove the attacker we just found
// from the bitboards and scan for new X-ray attacks behind it.

template<int Pt>
PieceType min_attacker(const Bitboard* byTypeBB, Square to, Bitboard stmAttackers,
                       Bitboard& occupied, Bitboard& attackers) {

  Bitboard b = stmAttackers & byTypeBB[Pt];
  if (!b)
      return min_attacker<Pt + 1>(byTypeBB, to, stmAttackers, occupied, attackers);

  occupied ^= lsb(b); // Remove the attacker from occupied

  // Add any X-ray attack behind the just removed piece. For instance with
  // rooks in a8 and a7 attacking a1, after removing a7 we add rook in a8.
  // Note that new added attackers can be of any color.
  if (Pt == PAWN || Pt == BISHOP || Pt == QUEEN)
      attackers |= attacks_bb<BISHOP>(to, occupied) & (byTypeBB[BISHOP] | byTypeBB[QUEEN]);

  if (Pt == ROOK || Pt == QUEEN)
      attackers |= attacks_bb<ROOK>(to, occupied) & (byTypeBB[ROOK] | byTypeBB[QUEEN]);

  // X-ray may add already processed pieces because byTypeBB[] is constant: in
  // the rook example, now attackers contains _again_ rook in a7, so remove it.
  attackers &= occupied;
  return (PieceType)Pt;
}

template<>
PieceType min_attacker<KING>(const Bitboard*, Square, Bitboard, Bitboard&, Bitboard&) {
  return KING; // No need to update bitboards: it is the last cycle
}

} // namespace


/// operator<<(Position) returns an ASCII representation of the position

std::ostream& operator<<(std::ostream& os, const Position& pos) {

  os << "\n +---+---+---+---+---+---+---+---+\n";

  for (Rank r = RANK_8; r >= RANK_1; --r)
  {
      for (File f = FILE_A; f <= FILE_H; ++f)
          os << " | " << PieceToChar[pos.piece_on(make_square(f, r))];

      os << " |\n +---+---+---+---+---+---+---+---+\n";
  }

  os << "\nFen: " << pos.fen() << "\nKey: " << std::hex << std::uppercase
     << std::setfill('0') << std::setw(16) << pos.key()
     << std::setfill(' ') << std::dec << "\nCheckers: ";

  for (Bitboard b = pos.checkers(); b; )
      os << UCI::square(pop_lsb(&b)) << " ";

  if (    int(Tablebases::MaxCardinality) >= popcount(pos.pieces())
      && !pos.can_castle(ANY_CASTLING))
  {
      StateInfo st;
      Position p;
      p.set(pos.fen(), pos.is_chess960(), &st, pos.this_thread());
      Tablebases::ProbeState s1, s2;
      Tablebases::WDLScore wdl = Tablebases::probe_wdl(p, &s1);
      int dtz = Tablebases::probe_dtz(p, &s2);
      os << "\nTablebases WDL: " << std::setw(4) << wdl << " (" << s1 << ")"
         << "\nTablebases DTZ: " << std::setw(4) << dtz << " (" << s2 << ")";
  }

  return os;
}


/// Position::init() initializes at startup the various arrays used to compute
/// hash keys.

void Position::init() {

  Zobrist::psq[1][0] = 591679071752537765;
  Zobrist::psq[1][1] = 11781298203991720739;
  Zobrist::psq[1][2] = 17774509420834274491;
  Zobrist::psq[1][3] = 93833316982319649;
  Zobrist::psq[1][4] = 5077288827755375591;
  Zobrist::psq[1][5] = 12650468822090308278;
  Zobrist::psq[1][6] = 7282142511083249914;
  Zobrist::psq[1][7] = 10536503665313592279;
  Zobrist::psq[1][8] = 4539792784031873725;
  Zobrist::psq[1][9] = 2841870292508388689;
  Zobrist::psq[1][10] = 15413206348252250872;
  Zobrist::psq[1][11] = 7678569077154129441;
  Zobrist::psq[1][12] = 13346546310876667408;
  Zobrist::psq[1][13] = 18288271767696598454;
  Zobrist::psq[1][14] = 10369369943721775254;
  Zobrist::psq[1][15] = 18081987910875800766;
  Zobrist::psq[1][16] = 5538285989180528017;
  Zobrist::psq[1][17] = 1561342000895978098;
  Zobrist::psq[1][18] = 344529452680813775;
  Zobrist::psq[1][19] = 12666574946949763448;
  Zobrist::psq[1][20] = 11485456468243178719;
  Zobrist::psq[1][21] = 7930595158480463155;
  Zobrist::psq[1][22] = 14302725423041560508;
  Zobrist::psq[1][23] = 14331261293281981139;
  Zobrist::psq[1][24] = 4456874005134181239;
  Zobrist::psq[1][25] = 2824504039224593559;
  Zobrist::psq[1][26] = 10380971965294849792;
  Zobrist::psq[1][27] = 15120440200421969569;
  Zobrist::psq[1][28] = 2459658218254782268;
  Zobrist::psq[1][29] = 3478717432759217624;
  Zobrist::psq[1][30] = 3378985187684316967;
  Zobrist::psq[1][31] = 9696037458963191704;
  Zobrist::psq[1][32] = 13098241107727776933;
  Zobrist::psq[1][33] = 16711523013166202616;
  Zobrist::psq[1][34] = 10079083771611825891;
  Zobrist::psq[1][35] = 14137347994420603547;
  Zobrist::psq[1][36] = 4791805899784156187;
  Zobrist::psq[1][37] = 6078389034317276724;
  Zobrist::psq[1][38] = 5994547221653596060;
  Zobrist::psq[1][39] = 16213379374441749196;
  Zobrist::psq[1][40] = 4600174966381648954;
  Zobrist::psq[1][41] = 2382793282151591793;
  Zobrist::psq[1][42] = 5441064086789571698;
  Zobrist::psq[1][43] = 13211067155709920737;
  Zobrist::psq[1][44] = 8095577678192451481;
  Zobrist::psq[1][45] = 12870220845239618167;
  Zobrist::psq[1][46] = 18366225606586112739;
  Zobrist::psq[1][47] = 1482740430229529117;
  Zobrist::psq[1][48] = 18398763828894394702;
  Zobrist::psq[1][49] = 12894175299039183743;
  Zobrist::psq[1][50] = 5973205243991449651;
  Zobrist::psq[1][51] = 16073805277627490771;
  Zobrist::psq[1][52] = 11840382123049768615;
  Zobrist::psq[1][53] = 16782637305176790952;
  Zobrist::psq[1][54] = 16565939816889406374;
  Zobrist::psq[1][55] = 7611013259146743987;
  Zobrist::psq[1][56] = 4325631834421711187;
  Zobrist::psq[1][57] = 7084652077183601842;
  Zobrist::psq[1][58] = 14113904950837697704;
  Zobrist::psq[1][59] = 6952439085241219742;
  Zobrist::psq[1][60] = 11697893679396085013;
  Zobrist::psq[1][61] = 15932411745698688381;
  Zobrist::psq[1][62] = 333938476871428781;
  Zobrist::psq[1][63] = 10094356940478519713;
  Zobrist::psq[2][0] = 8854028305631117351;
  Zobrist::psq[2][1] = 18264149368209609558;
  Zobrist::psq[2][2] = 18152850504025660547;
  Zobrist::psq[2][3] = 445125824226036916;
  Zobrist::psq[2][4] = 7445032221575161576;
  Zobrist::psq[2][5] = 5887372625995221418;
  Zobrist::psq[2][6] = 12579614965563241976;
  Zobrist::psq[2][7] = 15542129933905340102;
  Zobrist::psq[2][8] = 4278411582816540073;
  Zobrist::psq[2][9] = 7817987688731403418;
  Zobrist::psq[2][10] = 16765308846548980593;
  Zobrist::psq[2][11] = 15594655397588023405;
  Zobrist::psq[2][12] = 11116801254932199266;
  Zobrist::psq[2][13] = 11592572287770353464;
  Zobrist::psq[2][14] = 10698558469286656858;
  Zobrist::psq[2][15] = 263236209937302172;
  Zobrist::psq[2][16] = 15461982991340303336;
  Zobrist::psq[2][17] = 3043744698521235658;
  Zobrist::psq[2][18] = 1070442759222213040;
  Zobrist::psq[2][19] = 650534245804607543;
  Zobrist::psq[2][20] = 5943000432800778858;
  Zobrist::psq[2][21] = 26206987068637543;
  Zobrist::psq[2][22] = 16737080395141468053;
  Zobrist::psq[2][23] = 13977415469856941557;
  Zobrist::psq[2][24] = 1052117838564742180;
  Zobrist::psq[2][25] = 9424311196719389450;
  Zobrist::psq[2][26] = 12167498318705983564;
  Zobrist::psq[2][27] = 4301764225574437137;
  Zobrist::psq[2][28] = 17360266336634281276;
  Zobrist::psq[2][29] = 13868884065264943813;
  Zobrist::psq[2][30] = 15952283905104982306;
  Zobrist::psq[2][31] = 4998386290424363477;
  Zobrist::psq[2][32] = 4893239286087369377;
  Zobrist::psq[2][33] = 17573528852960048629;
  Zobrist::psq[2][34] = 2412201799238683587;
  Zobrist::psq[2][35] = 16517545668683925387;
  Zobrist::psq[2][36] = 16978748896271686395;
  Zobrist::psq[2][37] = 8830712609912112615;
  Zobrist::psq[2][38] = 244676446090624528;
  Zobrist::psq[2][39] = 10801320743593590304;
  Zobrist::psq[2][40] = 13531918303924845431;
  Zobrist::psq[2][41] = 10527125009130628070;
  Zobrist::psq[2][42] = 17495106538955645767;
  Zobrist::psq[2][43] = 14203433425689676251;
  Zobrist::psq[2][44] = 13760149572603586785;
  Zobrist::psq[2][45] = 1273129856199637694;
  Zobrist::psq[2][46] = 3154213753511759364;
  Zobrist::psq[2][47] = 12760143787594064657;
  Zobrist::psq[2][48] = 1600035040276021173;
  Zobrist::psq[2][49] = 5414819345072334853;
  Zobrist::psq[2][50] = 7201040945210650872;
  Zobrist::psq[2][51] = 11015789609492649674;
  Zobrist::psq[2][52] = 7712150959425383900;
  Zobrist::psq[2][53] = 8543311100722720016;
  Zobrist::psq[2][54] = 13076185511676908731;
  Zobrist::psq[2][55] = 3922562784470822468;
  Zobrist::psq[2][56] = 2780562387024492132;
  Zobrist::psq[2][57] = 6697120216501611455;
  Zobrist::psq[2][58] = 13480343126040452106;
  Zobrist::psq[2][59] = 12173667680050468927;
  Zobrist::psq[2][60] = 3302171945877565923;
  Zobrist::psq[2][61] = 16568602182162993491;
  Zobrist::psq[2][62] = 14953223006496535120;
  Zobrist::psq[2][63] = 16457941142416543492;
  Zobrist::psq[3][0] = 2945262940327718556;
  Zobrist::psq[3][1] = 3775538624233802005;
  Zobrist::psq[3][2] = 4292201895252289600;
  Zobrist::psq[3][3] = 16433809973923446677;
  Zobrist::psq[3][4] = 1284774014851141252;
  Zobrist::psq[3][5] = 18314932087213148495;
  Zobrist::psq[3][6] = 8946796353798605717;
  Zobrist::psq[3][7] = 16445820069092145103;
  Zobrist::psq[3][8] = 7588664147775519679;
  Zobrist::psq[3][9] = 12896594212779880816;
  Zobrist::psq[3][10] = 14935880823937687725;
  Zobrist::psq[3][11] = 13400879436137989525;
  Zobrist::psq[3][12] = 13846969535995712591;
  Zobrist::psq[3][13] = 12484917729738156524;
  Zobrist::psq[3][14] = 17882592831712409952;
  Zobrist::psq[3][15] = 16637473249645425632;
  Zobrist::psq[3][16] = 15098223454147433904;
  Zobrist::psq[3][17] = 17631249017957605294;
  Zobrist::psq[3][18] = 12582001597670293135;
  Zobrist::psq[3][19] = 17902661106057732664;
  Zobrist::psq[3][20] = 10274060743048400565;
  Zobrist::psq[3][21] = 12005958760542442625;
  Zobrist::psq[3][22] = 6324932172735347303;
  Zobrist::psq[3][23] = 17192330553585486663;
  Zobrist::psq[3][24] = 9422872207407330841;
  Zobrist::psq[3][25] = 3177237980255163711;
  Zobrist::psq[3][26] = 14998024116488875998;
  Zobrist::psq[3][27] = 705793604453777656;
  Zobrist::psq[3][28] = 11327568552142987041;
  Zobrist::psq[3][29] = 7029368612848231507;
  Zobrist::psq[3][30] = 11062860980165499825;
  Zobrist::psq[3][31] = 2900628512702115887;
  Zobrist::psq[3][32] = 308431256844078091;
  Zobrist::psq[3][33] = 752802454931337639;
  Zobrist::psq[3][34] = 5576583881995601144;
  Zobrist::psq[3][35] = 8733594096989903760;
  Zobrist::psq[3][36] = 290737499942622970;
  Zobrist::psq[3][37] = 8992780576699235245;
  Zobrist::psq[3][38] = 10425616809589311900;
  Zobrist::psq[3][39] = 5493674620779310265;
  Zobrist::psq[3][40] = 12589103349525344891;
  Zobrist::psq[3][41] = 14857852059215963628;
  Zobrist::psq[3][42] = 13495551423272463104;
  Zobrist::psq[3][43] = 6944056268429507318;
  Zobrist::psq[3][44] = 3988842613368812515;
  Zobrist::psq[3][45] = 14815775969275954512;
  Zobrist::psq[3][46] = 17868612272134391879;
  Zobrist::psq[3][47] = 8436706119115607049;
  Zobrist::psq[3][48] = 7555807622404432493;
  Zobrist::psq[3][49] = 9144495607954586305;
  Zobrist::psq[3][50] = 6794801016890317083;
  Zobrist::psq[3][51] = 6072558259768997948;
  Zobrist::psq[3][52] = 10941535447546794938;
  Zobrist::psq[3][53] = 14043502401785556544;
  Zobrist::psq[3][54] = 8362621443508695308;
  Zobrist::psq[3][55] = 17736840905212253027;
  Zobrist::psq[3][56] = 2733031211210449030;
  Zobrist::psq[3][57] = 4350365705834634871;
  Zobrist::psq[3][58] = 1100550212031776323;
  Zobrist::psq[3][59] = 17430963890314521917;
  Zobrist::psq[3][60] = 7470064030368587841;
  Zobrist::psq[3][61] = 13387014036020469860;
  Zobrist::psq[3][62] = 7078824284187344392;
  Zobrist::psq[3][63] = 12312007608706932222;
  Zobrist::psq[4][0] = 3826719064958106391;
  Zobrist::psq[4][1] = 17580452432494632735;
  Zobrist::psq[4][2] = 4372818848456885156;
  Zobrist::psq[4][3] = 20778095608392735;
  Zobrist::psq[4][4] = 9517712183106565981;
  Zobrist::psq[4][5] = 16772576131911258204;
  Zobrist::psq[4][6] = 12158847832281029501;
  Zobrist::psq[4][7] = 18318866654963083744;
  Zobrist::psq[4][8] = 14355784966049388499;
  Zobrist::psq[4][9] = 1442237715923966096;
  Zobrist::psq[4][10] = 16767620159370203923;
  Zobrist::psq[4][11] = 13501017873225644439;
  Zobrist::psq[4][12] = 12414460951753850741;
  Zobrist::psq[4][13] = 1630390626826320339;
  Zobrist::psq[4][14] = 11056926288496765292;
  Zobrist::psq[4][15] = 17514919132679636196;
  Zobrist::psq[4][16] = 6737125905271376420;
  Zobrist::psq[4][17] = 3156370395448333753;
  Zobrist::psq[4][18] = 7372374977020439436;
  Zobrist::psq[4][19] = 5277883516136612451;
  Zobrist::psq[4][20] = 16544956564115640970;
  Zobrist::psq[4][21] = 14431129579433994133;
  Zobrist::psq[4][22] = 10776067565185448;
  Zobrist::psq[4][23] = 15235680854177679657;
  Zobrist::psq[4][24] = 12767627681826077225;
  Zobrist::psq[4][25] = 1324675096273909386;
  Zobrist::psq[4][26] = 3456463189867507715;
  Zobrist::psq[4][27] = 9195964142578403484;
  Zobrist::psq[4][28] = 10627443539470127577;
  Zobrist::psq[4][29] = 7083655917886846512;
  Zobrist::psq[4][30] = 14734414825071094346;
  Zobrist::psq[4][31] = 8833975264052769557;
  Zobrist::psq[4][32] = 2965232458494052289;
  Zobrist::psq[4][33] = 12786367183060552144;
  Zobrist::psq[4][34] = 6364751811635930008;
  Zobrist::psq[4][35] = 12304694438192434386;
  Zobrist::psq[4][36] = 4420057912710567321;
  Zobrist::psq[4][37] = 13121826629733594974;
  Zobrist::psq[4][38] = 3295424378969736960;
  Zobrist::psq[4][39] = 16543444358261923928;
  Zobrist::psq[4][40] = 13665696745413941685;
  Zobrist::psq[4][41] = 3585618043384929225;
  Zobrist::psq[4][42] = 14758422515963078108;
  Zobrist::psq[4][43] = 5444185746065710993;
  Zobrist::psq[4][44] = 6217807121864929894;
  Zobrist::psq[4][45] = 7617121805124236390;
  Zobrist::psq[4][46] = 2176332518208481987;
  Zobrist::psq[4][47] = 1435617355844826626;
  Zobrist::psq[4][48] = 17897291909516933347;
  Zobrist::psq[4][49] = 17430612766366810879;
  Zobrist::psq[4][50] = 13845907184570465897;
  Zobrist::psq[4][51] = 3432307431600566936;
  Zobrist::psq[4][52] = 2532253559171451888;
  Zobrist::psq[4][53] = 11643128737472459646;
  Zobrist::psq[4][54] = 13606171979107604790;
  Zobrist::psq[4][55] = 10012509558550373270;
  Zobrist::psq[4][56] = 5587706015190365982;
  Zobrist::psq[4][57] = 18189230678861289336;
  Zobrist::psq[4][58] = 5637318834313874969;
  Zobrist::psq[4][59] = 4728172345191419793;
  Zobrist::psq[4][60] = 13287099661014164329;
  Zobrist::psq[4][61] = 8475766932330124954;
  Zobrist::psq[4][62] = 2781312650135424674;
  Zobrist::psq[4][63] = 10552294945874175633;
  Zobrist::psq[5][0] = 14116194119706301666;
  Zobrist::psq[5][1] = 908994258594572803;
  Zobrist::psq[5][2] = 3835251526534030662;
  Zobrist::psq[5][3] = 3902806174142003247;
  Zobrist::psq[5][4] = 8404113168045990162;
  Zobrist::psq[5][5] = 10605456791970677788;
  Zobrist::psq[5][6] = 8371724936653327204;
  Zobrist::psq[5][7] = 10149265301602815302;
  Zobrist::psq[5][8] = 10280163375965480302;
  Zobrist::psq[5][9] = 12878458563073396434;
  Zobrist::psq[5][10] = 1480273033205949154;
  Zobrist::psq[5][11] = 15420639285122262859;
  Zobrist::psq[5][12] = 16040433549230388361;
  Zobrist::psq[5][13] = 10889445127567090568;
  Zobrist::psq[5][14] = 7154846977618541400;
  Zobrist::psq[5][15] = 15324267473561911299;
  Zobrist::psq[5][16] = 9123044315927273855;
  Zobrist::psq[5][17] = 18178395620988860923;
  Zobrist::psq[5][18] = 13937825686985326355;
  Zobrist::psq[5][19] = 6208640256728026680;
  Zobrist::psq[5][20] = 17803354189602776349;
  Zobrist::psq[5][21] = 8168466387959732965;
  Zobrist::psq[5][22] = 4747388335999020093;
  Zobrist::psq[5][23] = 8076893647775627477;
  Zobrist::psq[5][24] = 135355862477779318;
  Zobrist::psq[5][25] = 13727020784074293322;
  Zobrist::psq[5][26] = 16471001867829363208;
  Zobrist::psq[5][27] = 3944848361583366045;
  Zobrist::psq[5][28] = 6153835027004876065;
  Zobrist::psq[5][29] = 17541053953916494135;
  Zobrist::psq[5][30] = 830442639195732299;
  Zobrist::psq[5][31] = 5707759661195251524;
  Zobrist::psq[5][32] = 16745928189385382169;
  Zobrist::psq[5][33] = 13853872449862111272;
  Zobrist::psq[5][34] = 10763276423780512808;
  Zobrist::psq[5][35] = 528748578239178413;
  Zobrist::psq[5][36] = 1195366693239264477;
  Zobrist::psq[5][37] = 16072813688416096526;
  Zobrist::psq[5][38] = 9411878730995839744;
  Zobrist::psq[5][39] = 14250860229846220116;
  Zobrist::psq[5][40] = 3391112600086567492;
  Zobrist::psq[5][41] = 11283764167692931512;
  Zobrist::psq[5][42] = 1672248607577385754;
  Zobrist::psq[5][43] = 2130286739811077583;
  Zobrist::psq[5][44] = 18311727561747759139;
  Zobrist::psq[5][45] = 974583822133342724;
  Zobrist::psq[5][46] = 5061116103402273638;
  Zobrist::psq[5][47] = 3126855720952116346;
  Zobrist::psq[5][48] = 578870949780164607;
  Zobrist::psq[5][49] = 3776778176701636327;
  Zobrist::psq[5][50] = 14213795876687685078;
  Zobrist::psq[5][51] = 5613780124034108946;
  Zobrist::psq[5][52] = 6069741268072432820;
  Zobrist::psq[5][53] = 8893641350514130178;
  Zobrist::psq[5][54] = 15249957078178864452;
  Zobrist::psq[5][55] = 18092583129505773527;
  Zobrist::psq[5][56] = 11393903435307203091;
  Zobrist::psq[5][57] = 8119660695860781220;
  Zobrist::psq[5][58] = 13766130452052543028;
  Zobrist::psq[5][59] = 7096579372531132405;
  Zobrist::psq[5][60] = 7459026647266724422;
  Zobrist::psq[5][61] = 5897616920394564481;
  Zobrist::psq[5][62] = 4162427946331299898;
  Zobrist::psq[5][63] = 2527789185948800525;
  Zobrist::psq[6][0] = 17290988795360054066;
  Zobrist::psq[6][1] = 5240905960030703813;
  Zobrist::psq[6][2] = 12532957579127022568;
  Zobrist::psq[6][3] = 7321214839249116978;
  Zobrist::psq[6][4] = 17188130528816882357;
  Zobrist::psq[6][5] = 13649660060729335176;
  Zobrist::psq[6][6] = 7877670809777050873;
  Zobrist::psq[6][7] = 8603165736220767331;
  Zobrist::psq[6][8] = 3731409983944574110;
  Zobrist::psq[6][9] = 14311591814980160037;
  Zobrist::psq[6][10] = 16719365103710912831;
  Zobrist::psq[6][11] = 15645061390881301878;
  Zobrist::psq[6][12] = 15313601992567477463;
  Zobrist::psq[6][13] = 558437165307320475;
  Zobrist::psq[6][14] = 10107592147679710958;
  Zobrist::psq[6][15] = 217058993405149273;
  Zobrist::psq[6][16] = 11583857652496458642;
  Zobrist::psq[6][17] = 12813267508475749642;
  Zobrist::psq[6][18] = 12801463184548517903;
  Zobrist::psq[6][19] = 10205205656182355892;
  Zobrist::psq[6][20] = 12009517757124415757;
  Zobrist::psq[6][21] = 11711220569788417590;
  Zobrist::psq[6][22] = 601506575385147719;
  Zobrist::psq[6][23] = 2403800598476663693;
  Zobrist::psq[6][24] = 3185273191806365666;
  Zobrist::psq[6][25] = 16311384682203900813;
  Zobrist::psq[6][26] = 2147738008043402447;
  Zobrist::psq[6][27] = 11784653004849107439;
  Zobrist::psq[6][28] = 11363702615030984814;
  Zobrist::psq[6][29] = 4459820841160151625;
  Zobrist::psq[6][30] = 17238855191434604666;
  Zobrist::psq[6][31] = 16533107622905015899;
  Zobrist::psq[6][32] = 12580437090734268666;
  Zobrist::psq[6][33] = 9002238121826321187;
  Zobrist::psq[6][34] = 7209727037264965188;
  Zobrist::psq[6][35] = 15210303941751662984;
  Zobrist::psq[6][36] = 5957580827072516578;
  Zobrist::psq[6][37] = 16077971979351817631;
  Zobrist::psq[6][38] = 7451935491114626499;
  Zobrist::psq[6][39] = 14243752318712699139;
  Zobrist::psq[6][40] = 12737894796843349185;
  Zobrist::psq[6][41] = 1351996896321498360;
  Zobrist::psq[6][42] = 4395539424431256646;
  Zobrist::psq[6][43] = 14636926406778905296;
  Zobrist::psq[6][44] = 10637364485216545239;
  Zobrist::psq[6][45] = 4709900282812548306;
  Zobrist::psq[6][46] = 14703591130731831913;
  Zobrist::psq[6][47] = 1476367765688281237;
  Zobrist::psq[6][48] = 4113914727206496161;
  Zobrist::psq[6][49] = 8066049843497142643;
  Zobrist::psq[6][50] = 7809561412546830570;
  Zobrist::psq[6][51] = 4879538739185105394;
  Zobrist::psq[6][52] = 9498083046807871856;
  Zobrist::psq[6][53] = 17559505952950827343;
  Zobrist::psq[6][54] = 11763387757765891631;
  Zobrist::psq[6][55] = 10055035698587107604;
  Zobrist::psq[6][56] = 12844734664424373030;
  Zobrist::psq[6][57] = 330991544207939447;
  Zobrist::psq[6][58] = 8508732305896661743;
  Zobrist::psq[6][59] = 11153570973223855023;
  Zobrist::psq[6][60] = 10238055872248257461;
  Zobrist::psq[6][61] = 1773280948989896239;
  Zobrist::psq[6][62] = 8300833427522849187;
  Zobrist::psq[6][63] = 10832779467616436194;
  Zobrist::psq[9][0] = 11781789245711860189;
  Zobrist::psq[9][1] = 2747882707407274161;
  Zobrist::psq[9][2] = 3724767368808293169;
  Zobrist::psq[9][3] = 10298180063630105197;
  Zobrist::psq[9][4] = 10746438658164496957;
  Zobrist::psq[9][5] = 16037040440297371558;
  Zobrist::psq[9][6] = 17588125462232966688;
  Zobrist::psq[9][7] = 6880843334474042246;
  Zobrist::psq[9][8] = 560415017990002212;
  Zobrist::psq[9][9] = 6626394159937994533;
  Zobrist::psq[9][10] = 2670333323665803600;
  Zobrist::psq[9][11] = 4280458366389177326;
  Zobrist::psq[9][12] = 1467978672011198404;
  Zobrist::psq[9][13] = 7620133404071416883;
  Zobrist::psq[9][14] = 13350367343504972530;
  Zobrist::psq[9][15] = 10138430730509076413;
  Zobrist::psq[9][16] = 6785953884329063615;
  Zobrist::psq[9][17] = 4006903721835701728;
  Zobrist::psq[9][18] = 17529175408771439641;
  Zobrist::psq[9][19] = 2257868868401674686;
  Zobrist::psq[9][20] = 16350586259217027048;
  Zobrist::psq[9][21] = 12792669610269240489;
  Zobrist::psq[9][22] = 15445432911128260212;
  Zobrist::psq[9][23] = 3830919760132254685;
  Zobrist::psq[9][24] = 17463139367032047470;
  Zobrist::psq[9][25] = 15002266175994648649;
  Zobrist::psq[9][26] = 17680514289072042202;
  Zobrist::psq[9][27] = 362761448860517629;
  Zobrist::psq[9][28] = 2620716836644167551;
  Zobrist::psq[9][29] = 10876826577342073644;
  Zobrist::psq[9][30] = 14704635783604247913;
  Zobrist::psq[9][31] = 8370308497378149181;
  Zobrist::psq[9][32] = 16902199073103511157;
  Zobrist::psq[9][33] = 4712050710770633961;
  Zobrist::psq[9][34] = 2335277171236964126;
  Zobrist::psq[9][35] = 15454330651988402294;
  Zobrist::psq[9][36] = 6039398895644425870;
  Zobrist::psq[9][37] = 5330935207425949713;
  Zobrist::psq[9][38] = 6844204079868621004;
  Zobrist::psq[9][39] = 15018633515897982115;
  Zobrist::psq[9][40] = 5869887878873962697;
  Zobrist::psq[9][41] = 9619421978703093664;
  Zobrist::psq[9][42] = 7065039212033014872;
  Zobrist::psq[9][43] = 14085021312833583897;
  Zobrist::psq[9][44] = 17738639966636660046;
  Zobrist::psq[9][45] = 18274309123980813514;
  Zobrist::psq[9][46] = 16007640215959475868;
  Zobrist::psq[9][47] = 4326793000252505639;
  Zobrist::psq[9][48] = 11694193434453531305;
  Zobrist::psq[9][49] = 15789397716808962025;
  Zobrist::psq[9][50] = 8672273831614123897;
  Zobrist::psq[9][51] = 6109915657282875177;
  Zobrist::psq[9][52] = 6240221177136276484;
  Zobrist::psq[9][53] = 17650760467278016265;
  Zobrist::psq[9][54] = 13635783915766085055;
  Zobrist::psq[9][55] = 17178975703249397658;
  Zobrist::psq[9][56] = 690100752037560272;
  Zobrist::psq[9][57] = 846594232046156050;
  Zobrist::psq[9][58] = 11437611220054444781;
  Zobrist::psq[9][59] = 1050411833588837386;
  Zobrist::psq[9][60] = 10485589741397417446;
  Zobrist::psq[9][61] = 12844414679888429939;
  Zobrist::psq[9][62] = 6491358656106542835;
  Zobrist::psq[9][63] = 12575464921310399912;
  Zobrist::psq[10][0] = 14923825269739949453;
  Zobrist::psq[10][1] = 18375002115249413557;
  Zobrist::psq[10][2] = 3423036550911737589;
  Zobrist::psq[10][3] = 15250861506191355802;
  Zobrist::psq[10][4] = 15031961129285356212;
  Zobrist::psq[10][5] = 15435012606837965840;
  Zobrist::psq[10][6] = 6304673951675292305;
  Zobrist::psq[10][7] = 12785716655315370815;
  Zobrist::psq[10][8] = 9808873325341612945;
  Zobrist::psq[10][9] = 9783992785966697331;
  Zobrist::psq[10][10] = 18138650430907468530;
  Zobrist::psq[10][11] = 18431297401347671031;
  Zobrist::psq[10][12] = 18148129570815566817;
  Zobrist::psq[10][13] = 12696743950740820713;
  Zobrist::psq[10][14] = 1854845205476015706;
  Zobrist::psq[10][15] = 12865777516920439176;
  Zobrist::psq[10][16] = 15636159047245426328;
  Zobrist::psq[10][17] = 17373407353156678628;
  Zobrist::psq[10][18] = 2495834645782650553;
  Zobrist::psq[10][19] = 11247757644603045972;
  Zobrist::psq[10][20] = 17130748698210142189;
  Zobrist::psq[10][21] = 11422966446976074719;
  Zobrist::psq[10][22] = 1595016003613213710;
  Zobrist::psq[10][23] = 3899856913033553150;
  Zobrist::psq[10][24] = 15470414105568996654;
  Zobrist::psq[10][25] = 2572459120480840982;
  Zobrist::psq[10][26] = 14288318049370965601;
  Zobrist::psq[10][27] = 4034656711994978492;
  Zobrist::psq[10][28] = 3619462250265206907;
  Zobrist::psq[10][29] = 12564616267900212223;
  Zobrist::psq[10][30] = 6563888989859451823;
  Zobrist::psq[10][31] = 2454157599688795602;
  Zobrist::psq[10][32] = 122761158351497116;
  Zobrist::psq[10][33] = 4118064480546384385;
  Zobrist::psq[10][34] = 13825342760651713002;
  Zobrist::psq[10][35] = 3757958894065091138;
  Zobrist::psq[10][36] = 3348351562535718824;
  Zobrist::psq[10][37] = 11085064257829065607;
  Zobrist::psq[10][38] = 4791949565677098244;
  Zobrist::psq[10][39] = 16741859899153424134;
  Zobrist::psq[10][40] = 13552228277894027114;
  Zobrist::psq[10][41] = 18043793947072687525;
  Zobrist::psq[10][42] = 18232133385309552782;
  Zobrist::psq[10][43] = 17162542170033385071;
  Zobrist::psq[10][44] = 17966719644677930276;
  Zobrist::psq[10][45] = 4126374944389900134;
  Zobrist::psq[10][46] = 7694029693525104626;
  Zobrist::psq[10][47] = 7844796758498075948;
  Zobrist::psq[10][48] = 15171322352384637386;
  Zobrist::psq[10][49] = 4901284706517591019;
  Zobrist::psq[10][50] = 11550611493505829690;
  Zobrist::psq[10][51] = 8591758722916550176;
  Zobrist::psq[10][52] = 6614280899913466481;
  Zobrist::psq[10][53] = 15659292666557594854;
  Zobrist::psq[10][54] = 8334845918197067198;
  Zobrist::psq[10][55] = 14303347218899317731;
  Zobrist::psq[10][56] = 18185681713739197231;
  Zobrist::psq[10][57] = 10010957749676186008;
  Zobrist::psq[10][58] = 6151588837035247399;
  Zobrist::psq[10][59] = 15955998980864570780;
  Zobrist::psq[10][60] = 14725804664707294906;
  Zobrist::psq[10][61] = 9071111217904025772;
  Zobrist::psq[10][62] = 4268551186589045976;
  Zobrist::psq[10][63] = 3787505694838293655;
  Zobrist::psq[11][0] = 3463765996898474975;
  Zobrist::psq[11][1] = 1419043948633899671;
  Zobrist::psq[11][2] = 4738255775972431200;
  Zobrist::psq[11][3] = 10880687006345860054;
  Zobrist::psq[11][4] = 6083956890523873398;
  Zobrist::psq[11][5] = 15399367780949709721;
  Zobrist::psq[11][6] = 10077652868536637496;
  Zobrist::psq[11][7] = 4763774200646997281;
  Zobrist::psq[11][8] = 2058719554631509711;
  Zobrist::psq[11][9] = 16245257579300202929;
  Zobrist::psq[11][10] = 12549234361408101229;
  Zobrist::psq[11][11] = 5132111825598353706;
  Zobrist::psq[11][12] = 13210867931726967807;
  Zobrist::psq[11][13] = 8049587883156206974;
  Zobrist::psq[11][14] = 14208790774466773366;
  Zobrist::psq[11][15] = 15004789243215417478;
  Zobrist::psq[11][16] = 2705161721287640173;
  Zobrist::psq[11][17] = 6606951690346399114;
  Zobrist::psq[11][18] = 9038858141657157738;
  Zobrist::psq[11][19] = 9864507686211087503;
  Zobrist::psq[11][20] = 8174211780307618304;
  Zobrist::psq[11][21] = 16060351410629081351;
  Zobrist::psq[11][22] = 5484951598904056885;
  Zobrist::psq[11][23] = 12456759525904287919;
  Zobrist::psq[11][24] = 8919252620379965524;
  Zobrist::psq[11][25] = 15501107657356591656;
  Zobrist::psq[11][26] = 3242949188225361282;
  Zobrist::psq[11][27] = 5926058172544675863;
  Zobrist::psq[11][28] = 6405123151097452666;
  Zobrist::psq[11][29] = 172567736958909523;
  Zobrist::psq[11][30] = 17292315564005737229;
  Zobrist::psq[11][31] = 13464278685013338817;
  Zobrist::psq[11][32] = 3686053955562449182;
  Zobrist::psq[11][33] = 8857017014241158725;
  Zobrist::psq[11][34] = 15421895718306499875;
  Zobrist::psq[11][35] = 3815913251318905694;
  Zobrist::psq[11][36] = 3432648465599995302;
  Zobrist::psq[11][37] = 818320788389300537;
  Zobrist::psq[11][38] = 4071520112108071604;
  Zobrist::psq[11][39] = 13295466432639272442;
  Zobrist::psq[11][40] = 2426572569594491679;
  Zobrist::psq[11][41] = 10076303268977391406;
  Zobrist::psq[11][42] = 8784192232334006419;
  Zobrist::psq[11][43] = 2997181738853009670;
  Zobrist::psq[11][44] = 15770398685934330580;
  Zobrist::psq[11][45] = 13017264784195056557;
  Zobrist::psq[11][46] = 4330776497582490757;
  Zobrist::psq[11][47] = 10934498588458332802;
  Zobrist::psq[11][48] = 10356579632341837397;
  Zobrist::psq[11][49] = 2098241031318749487;
  Zobrist::psq[11][50] = 14789448409803449028;
  Zobrist::psq[11][51] = 11251433970760721438;
  Zobrist::psq[11][52] = 7224004101031043677;
  Zobrist::psq[11][53] = 15038935143876354117;
  Zobrist::psq[11][54] = 13215483265469582733;
  Zobrist::psq[11][55] = 1462298635979286935;
  Zobrist::psq[11][56] = 5759284467508932139;
  Zobrist::psq[11][57] = 5761810302276021825;
  Zobrist::psq[11][58] = 1946852319481058342;
  Zobrist::psq[11][59] = 8779292626819401953;
  Zobrist::psq[11][60] = 9980275774854520963;
  Zobrist::psq[11][61] = 9018156077605645253;
  Zobrist::psq[11][62] = 10175632970326281074;
  Zobrist::psq[11][63] = 17670251009423356428;
  Zobrist::psq[12][0] = 2047473063754745880;
  Zobrist::psq[12][1] = 4129462703004022451;
  Zobrist::psq[12][2] = 10030514736718131075;
  Zobrist::psq[12][3] = 8457187454173219884;
  Zobrist::psq[12][4] = 675824455430313366;
  Zobrist::psq[12][5] = 15722708499135010396;
  Zobrist::psq[12][6] = 1416150021210949828;
  Zobrist::psq[12][7] = 18340753630988628266;
  Zobrist::psq[12][8] = 4279562020148953383;
  Zobrist::psq[12][9] = 7599717795808621650;
  Zobrist::psq[12][10] = 8493385059263161629;
  Zobrist::psq[12][11] = 5448373608430482181;
  Zobrist::psq[12][12] = 7975000343659144004;
  Zobrist::psq[12][13] = 3661443877569162353;
  Zobrist::psq[12][14] = 17436434418308603210;
  Zobrist::psq[12][15] = 7723061412912586436;
  Zobrist::psq[12][16] = 12478269109366344372;
  Zobrist::psq[12][17] = 5260527761162561230;
  Zobrist::psq[12][18] = 3664808336308943032;
  Zobrist::psq[12][19] = 12246522629121956498;
  Zobrist::psq[12][20] = 11421384233946319246;
  Zobrist::psq[12][21] = 10711232448204740396;
  Zobrist::psq[12][22] = 394033332107778027;
  Zobrist::psq[12][23] = 1653867462011650260;
  Zobrist::psq[12][24] = 10614247855083729040;
  Zobrist::psq[12][25] = 3511207051989217747;
  Zobrist::psq[12][26] = 14828688729293007936;
  Zobrist::psq[12][27] = 12730238737606105501;
  Zobrist::psq[12][28] = 9131161340116597330;
  Zobrist::psq[12][29] = 10475424158865388660;
  Zobrist::psq[12][30] = 12216784836515690585;
  Zobrist::psq[12][31] = 12605719261947498045;
  Zobrist::psq[12][32] = 55059904350528673;
  Zobrist::psq[12][33] = 5668017292185949458;
  Zobrist::psq[12][34] = 5318848626170854652;
  Zobrist::psq[12][35] = 5812165408168894719;
  Zobrist::psq[12][36] = 12436591089168384586;
  Zobrist::psq[12][37] = 11456184110470635333;
  Zobrist::psq[12][38] = 17354703890556504985;
  Zobrist::psq[12][39] = 12819708191444916183;
  Zobrist::psq[12][40] = 2051969874001439467;
  Zobrist::psq[12][41] = 9752086654524583546;
  Zobrist::psq[12][42] = 8598830537031500033;
  Zobrist::psq[12][43] = 10803717843971298140;
  Zobrist::psq[12][44] = 17386254373003795027;
  Zobrist::psq[12][45] = 3490013643061567317;
  Zobrist::psq[12][46] = 14966160920336416174;
  Zobrist::psq[12][47] = 2716159408585464742;
  Zobrist::psq[12][48] = 13704057180721116715;
  Zobrist::psq[12][49] = 6139827121406310950;
  Zobrist::psq[12][50] = 12045645008689575811;
  Zobrist::psq[12][51] = 5879666907986225363;
  Zobrist::psq[12][52] = 18332108852121545326;
  Zobrist::psq[12][53] = 8302596541641486393;
  Zobrist::psq[12][54] = 3337300269606353125;
  Zobrist::psq[12][55] = 4641043901128821440;
  Zobrist::psq[12][56] = 17552658021160699704;
  Zobrist::psq[12][57] = 15245517114959849830;
  Zobrist::psq[12][58] = 898774234328201642;
  Zobrist::psq[12][59] = 13458365488972458856;
  Zobrist::psq[12][60] = 17617352963801145870;
  Zobrist::psq[12][61] = 12653043169047643133;
  Zobrist::psq[12][62] = 3946055118622982785;
  Zobrist::psq[12][63] = 78667567517654999;
  Zobrist::psq[13][0] = 7496345100749090134;
  Zobrist::psq[13][1] = 11141138397664383499;
  Zobrist::psq[13][2] = 9990861652354760086;
  Zobrist::psq[13][3] = 6136051413974204120;
  Zobrist::psq[13][4] = 14382251659553821084;
  Zobrist::psq[13][5] = 12222838175704680581;
  Zobrist::psq[13][6] = 9437743647758681312;
  Zobrist::psq[13][7] = 5321952072316248116;
  Zobrist::psq[13][8] = 9510472571572253025;
  Zobrist::psq[13][9] = 13968738580144591953;
  Zobrist::psq[13][10] = 9048732621241245672;
  Zobrist::psq[13][11] = 7070992119077796289;
  Zobrist::psq[13][12] = 7585987196905721881;
  Zobrist::psq[13][13] = 12797609451470009512;
  Zobrist::psq[13][14] = 13831169997283951441;
  Zobrist::psq[13][15] = 14062956797276305407;
  Zobrist::psq[13][16] = 7195172102806297836;
  Zobrist::psq[13][17] = 13763135782447679404;
  Zobrist::psq[13][18] = 8729177333120200902;
  Zobrist::psq[13][19] = 8228513033455726756;
  Zobrist::psq[13][20] = 5827889096510108059;
  Zobrist::psq[13][21] = 1541817158620711182;
  Zobrist::psq[13][22] = 18002525473269359251;
  Zobrist::psq[13][23] = 7210349805272776282;
  Zobrist::psq[13][24] = 6760744891923215431;
  Zobrist::psq[13][25] = 1684012349959865632;
  Zobrist::psq[13][26] = 5422658641223860702;
  Zobrist::psq[13][27] = 5964630753289401637;
  Zobrist::psq[13][28] = 16048931659747747714;
  Zobrist::psq[13][29] = 12995369105282084360;
  Zobrist::psq[13][30] = 2210225853011473806;
  Zobrist::psq[13][31] = 13310794355402477849;
  Zobrist::psq[13][32] = 4356361331354780175;
  Zobrist::psq[13][33] = 10920940233470324174;
  Zobrist::psq[13][34] = 4480682637160025854;
  Zobrist::psq[13][35] = 11920920861864075275;
  Zobrist::psq[13][36] = 17830720560385394644;
  Zobrist::psq[13][37] = 17667812763781863653;
  Zobrist::psq[13][38] = 8584251371203620679;
  Zobrist::psq[13][39] = 10083927648945854194;
  Zobrist::psq[13][40] = 15175717840117055506;
  Zobrist::psq[13][41] = 3402388332801799152;
  Zobrist::psq[13][42] = 17983756367024412696;
  Zobrist::psq[13][43] = 13633521765968038314;
  Zobrist::psq[13][44] = 18197623828188242686;
  Zobrist::psq[13][45] = 7159151014196207335;
  Zobrist::psq[13][46] = 6329323109608928752;
  Zobrist::psq[13][47] = 4596348075478973761;
  Zobrist::psq[13][48] = 1929043772203993371;
  Zobrist::psq[13][49] = 2942782730029388844;
  Zobrist::psq[13][50] = 17616535832761962408;
  Zobrist::psq[13][51] = 14638746212880920282;
  Zobrist::psq[13][52] = 235408037287298392;
  Zobrist::psq[13][53] = 15488773953079788133;
  Zobrist::psq[13][54] = 14511691540381881087;
  Zobrist::psq[13][55] = 4908241668947178463;
  Zobrist::psq[13][56] = 8002325218109467205;
  Zobrist::psq[13][57] = 384694259305835297;
  Zobrist::psq[13][58] = 4413022859932656147;
  Zobrist::psq[13][59] = 16084510603130945976;
  Zobrist::psq[13][60] = 7817184652260023923;
  Zobrist::psq[13][61] = 11521163704900182019;
  Zobrist::psq[13][62] = 10633473972031941012;
  Zobrist::psq[13][63] = 7028123206539359005;
  Zobrist::psq[14][0] = 12370129909167185711;
  Zobrist::psq[14][1] = 18282545875249343957;
  Zobrist::psq[14][2] = 11571910781648655955;
  Zobrist::psq[14][3] = 12044362528788437371;
  Zobrist::psq[14][4] = 15748959137105604538;
  Zobrist::psq[14][5] = 12433669315838447795;
  Zobrist::psq[14][6] = 3539341563356477798;
  Zobrist::psq[14][7] = 8229636981602574987;
  Zobrist::psq[14][8] = 18267920850505015981;
  Zobrist::psq[14][9] = 18135187956959905864;
  Zobrist::psq[14][10] = 10122403804874825725;
  Zobrist::psq[14][11] = 8577640427585662579;
  Zobrist::psq[14][12] = 16947872026033056961;
  Zobrist::psq[14][13] = 4498886674923994328;
  Zobrist::psq[14][14] = 5110446196942225801;
  Zobrist::psq[14][15] = 2443501881669395127;
  Zobrist::psq[14][16] = 6915148508579620831;
  Zobrist::psq[14][17] = 9154422921438056207;
  Zobrist::psq[14][18] = 3578030806440286511;
  Zobrist::psq[14][19] = 15315801991440539300;
  Zobrist::psq[14][20] = 7070866824836391168;
  Zobrist::psq[14][21] = 14817924832942381111;
  Zobrist::psq[14][22] = 3001446271118775643;
  Zobrist::psq[14][23] = 13000642695841600636;
  Zobrist::psq[14][24] = 14370567463871457833;
  Zobrist::psq[14][25] = 11030064684553339453;
  Zobrist::psq[14][26] = 14239970918075645415;
  Zobrist::psq[14][27] = 9415971121016597759;
  Zobrist::psq[14][28] = 6665243610733579451;
  Zobrist::psq[14][29] = 12729882327349519727;
  Zobrist::psq[14][30] = 127495542892799647;
  Zobrist::psq[14][31] = 6044073010763988256;
  Zobrist::psq[14][32] = 13007064564721953048;
  Zobrist::psq[14][33] = 13888665226332397302;
  Zobrist::psq[14][34] = 13536486134713258398;
  Zobrist::psq[14][35] = 16493663995181111698;
  Zobrist::psq[14][36] = 2130152061385863810;
  Zobrist::psq[14][37] = 5369940202574713097;
  Zobrist::psq[14][38] = 4976109024626592507;
  Zobrist::psq[14][39] = 17662718886951473514;
  Zobrist::psq[14][40] = 10194604604769366768;
  Zobrist::psq[14][41] = 9434649875492567077;
  Zobrist::psq[14][42] = 9275344374679790988;
  Zobrist::psq[14][43] = 13950395516943844512;
  Zobrist::psq[14][44] = 4634019286100624619;
  Zobrist::psq[14][45] = 17524913661501655732;
  Zobrist::psq[14][46] = 12758868016771465513;
  Zobrist::psq[14][47] = 3127147764315865797;
  Zobrist::psq[14][48] = 3960938717909563730;
  Zobrist::psq[14][49] = 14869830638616427590;
  Zobrist::psq[14][50] = 305185646789997459;
  Zobrist::psq[14][51] = 4139658351799906696;
  Zobrist::psq[14][52] = 272667046354598132;
  Zobrist::psq[14][53] = 15621274402096728762;
  Zobrist::psq[14][54] = 16483498129229512495;
  Zobrist::psq[14][55] = 12953368655171389128;
  Zobrist::psq[14][56] = 10678035399177741929;
  Zobrist::psq[14][57] = 18049652274331575310;
  Zobrist::psq[14][58] = 7975081034372805163;
  Zobrist::psq[14][59] = 10522098076497821829;
  Zobrist::psq[14][60] = 12606359703294662790;
  Zobrist::psq[14][61] = 13924857104548874958;
  Zobrist::psq[14][62] = 6566773282407180921;
  Zobrist::psq[14][63] = 3452471826952569846;
  Zobrist::enpassant[0] = 9031641776876329352;
  Zobrist::enpassant[1] = 12228382040141709029;
  Zobrist::enpassant[2] = 2494223668561036951;
  Zobrist::enpassant[3] = 7849557628814744642;
  Zobrist::enpassant[4] = 16000570245257669890;
  Zobrist::enpassant[5] = 16614404541835922253;
  Zobrist::enpassant[6] = 17787301719840479309;
  Zobrist::enpassant[7] = 6371708097697762807;
  Zobrist::castling[1] = 7487338029351702425;
  Zobrist::castling[2] = 10138645747811604478;
  Zobrist::castling[3] = 7487338029351702425;
  Zobrist::castling[3] = 16959407016388712551;
  Zobrist::castling[4] = 16332212992845378228;
  Zobrist::castling[5] = 7487338029351702425;
  Zobrist::castling[5] = 9606164174486469933;
  Zobrist::castling[6] = 10138645747811604478;
  Zobrist::castling[6] = 7931993123235079498;
  Zobrist::castling[7] = 7487338029351702425;
  Zobrist::castling[7] = 16959407016388712551;
  Zobrist::castling[7] = 719529192282958547;
  Zobrist::castling[8] = 6795873897769436611;
  Zobrist::castling[9] = 7487338029351702425;
  Zobrist::castling[9] = 4154453049008294490;
  Zobrist::castling[10] = 10138645747811604478;
  Zobrist::castling[10] = 15203167020455580221;
  Zobrist::castling[11] = 7487338029351702425;
  Zobrist::castling[11] = 16959407016388712551;
  Zobrist::castling[11] = 13048090984296504740;
  Zobrist::castling[12] = 16332212992845378228;
  Zobrist::castling[12] = 13612242447579281271;
  Zobrist::castling[13] = 7487338029351702425;
  Zobrist::castling[13] = 9606164174486469933;
  Zobrist::castling[13] = 15780674830245624046;
  Zobrist::castling[14] = 10138645747811604478;
  Zobrist::castling[14] = 7931993123235079498;
  Zobrist::castling[14] = 3484610688987504777;
  Zobrist::castling[15] = 7487338029351702425;
  Zobrist::castling[15] = 16959407016388712551;
  Zobrist::castling[15] = 719529192282958547;
  Zobrist::castling[15] = 6319549394931232528;
  Zobrist::side = 4906379431808431525;
}


/// Position::set() initializes the position object with the given FEN string.
/// This function is not very robust - make sure that input FENs are correct,
/// this is assumed to be the responsibility of the GUI.

Position& Position::set(const string& fenStr, bool isChess960, StateInfo* si, Thread* th) {
/*
   A FEN string defines a particular position using only the ASCII character set.

   A FEN string contains six fields separated by a space. The fields are:

   1) Piece placement (from white's perspective). Each rank is described, starting
      with rank 8 and ending with rank 1. Within each rank, the contents of each
      square are described from file A through file H. Following the Standard
      Algebraic Notation (SAN), each piece is identified by a single letter taken
      from the standard English names. White pieces are designated using upper-case
      letters ("PNBRQK") whilst Black uses lowercase ("pnbrqk"). Blank squares are
      noted using digits 1 through 8 (the number of blank squares), and "/"
      separates ranks.

   2) Active color. "w" means white moves next, "b" means black.

   3) Castling availability. If neither side can castle, this is "-". Otherwise,
      this has one or more letters: "K" (White can castle kingside), "Q" (White
      can castle queenside), "k" (Black can castle kingside), and/or "q" (Black
      can castle queenside).

   4) En passant target square (in algebraic notation). If there's no en passant
      target square, this is "-". If a pawn has just made a 2-square move, this
      is the position "behind" the pawn. This is recorded only if there is a pawn
      in position to make an en passant capture, and if there really is a pawn
      that might have advanced two squares.

   5) Halfmove clock. This is the number of halfmoves since the last pawn advance
      or capture. This is used to determine if a draw can be claimed under the
      fifty-move rule.

   6) Fullmove number. The number of the full move. It starts at 1, and is
      incremented after Black's move.
*/

  unsigned char col, row, token;
  size_t idx;
  Square sq = SQ_A8;
  std::istringstream ss(fenStr);

  std::memset(this, 0, sizeof(Position));
  std::memset(si, 0, sizeof(StateInfo));
  std::fill_n(&pieceList[0][0], sizeof(pieceList) / sizeof(Square), SQ_NONE);
  st = si;

  ss >> std::noskipws;

  // 1. Piece placement
  while ((ss >> token) && !isspace(token))
  {
      if (isdigit(token))
          sq += (token - '0') * EAST; // Advance the given number of files

      else if (token == '/')
          sq += 2 * SOUTH;

      else if ((idx = PieceToChar.find(token)) != string::npos)
      {
          put_piece(Piece(idx), sq);
          ++sq;
      }
  }

  // 2. Active color
  ss >> token;
  sideToMove = (token == 'w' ? WHITE : BLACK);
  ss >> token;

  // 3. Castling availability. Compatible with 3 standards: Normal FEN standard,
  // Shredder-FEN that uses the letters of the columns on which the rooks began
  // the game instead of KQkq and also X-FEN standard that, in case of Chess960,
  // if an inner rook is associated with the castling right, the castling tag is
  // replaced by the file letter of the involved rook, as for the Shredder-FEN.
  while ((ss >> token) && !isspace(token))
  {
      Square rsq;
      Color c = islower(token) ? BLACK : WHITE;
      Piece rook = make_piece(c, ROOK);

      token = char(toupper(token));

      if (token == 'K')
          for (rsq = relative_square(c, SQ_H1); piece_on(rsq) != rook; --rsq) {}

      else if (token == 'Q')
          for (rsq = relative_square(c, SQ_A1); piece_on(rsq) != rook; ++rsq) {}

      else if (token >= 'A' && token <= 'H')
          rsq = make_square(File(token - 'A'), relative_rank(c, RANK_1));

      else
          continue;

      set_castling_right(c, rsq);
  }

  // 4. En passant square. Ignore if no pawn capture is possible
  if (   ((ss >> col) && (col >= 'a' && col <= 'h'))
      && ((ss >> row) && (row == '3' || row == '6')))
  {
      st->epSquare = make_square(File(col - 'a'), Rank(row - '1'));

      if (   !(attackers_to(st->epSquare) & pieces(sideToMove, PAWN))
          || !(pieces(~sideToMove, PAWN) & (st->epSquare + pawn_push(~sideToMove))))
          st->epSquare = SQ_NONE;
  }
  else
      st->epSquare = SQ_NONE;

  // 5-6. Halfmove clock and fullmove number
  ss >> std::skipws >> st->rule50 >> gamePly;

  // Convert from fullmove starting from 1 to gamePly starting from 0,
  // handle also common incorrect FEN with fullmove = 0.
  gamePly = std::max(2 * (gamePly - 1), 0) + (sideToMove == BLACK);

  chess960 = isChess960;
  thisThread = th;
  set_state(st);

  assert(pos_is_ok());

  return *this;
}


/// Position::set_castling_right() is a helper function used to set castling
/// rights given the corresponding color and the rook starting square.

void Position::set_castling_right(Color c, Square rfrom) {

  Square kfrom = square<KING>(c);
  CastlingSide cs = kfrom < rfrom ? KING_SIDE : QUEEN_SIDE;
  CastlingRight cr = (c | cs);

  st->castlingRights |= cr;
  castlingRightsMask[kfrom] |= cr;
  castlingRightsMask[rfrom] |= cr;
  castlingRookSquare[cr] = rfrom;

  Square kto = relative_square(c, cs == KING_SIDE ? SQ_G1 : SQ_C1);
  Square rto = relative_square(c, cs == KING_SIDE ? SQ_F1 : SQ_D1);

  for (Square s = std::min(rfrom, rto); s <= std::max(rfrom, rto); ++s)
      if (s != kfrom && s != rfrom)
          castlingPath[cr] |= s;

  for (Square s = std::min(kfrom, kto); s <= std::max(kfrom, kto); ++s)
      if (s != kfrom && s != rfrom)
          castlingPath[cr] |= s;
}


/// Position::set_check_info() sets king attacks to detect if a move gives check

void Position::set_check_info(StateInfo* si) const {

  si->blockersForKing[WHITE] = slider_blockers(pieces(BLACK), square<KING>(WHITE), si->pinnersForKing[WHITE]);
  si->blockersForKing[BLACK] = slider_blockers(pieces(WHITE), square<KING>(BLACK), si->pinnersForKing[BLACK]);

  Square ksq = square<KING>(~sideToMove);

  si->checkSquares[PAWN]   = attacks_from<PAWN>(ksq, ~sideToMove);
  si->checkSquares[KNIGHT] = attacks_from<KNIGHT>(ksq);
  si->checkSquares[BISHOP] = attacks_from<BISHOP>(ksq);
  si->checkSquares[ROOK]   = attacks_from<ROOK>(ksq);
  si->checkSquares[QUEEN]  = si->checkSquares[BISHOP] | si->checkSquares[ROOK];
  si->checkSquares[KING]   = 0;
}


/// Position::set_state() computes the hash keys of the position, and other
/// data that once computed is updated incrementally as moves are made.
/// The function is only used when a new position is set up, and to verify
/// the correctness of the StateInfo data when running in debug mode.

void Position::set_state(StateInfo* si) const {

  si->key = si->materialKey = 0;
  si->pawnKey = Zobrist::noPawns;
  si->nonPawnMaterial[WHITE] = si->nonPawnMaterial[BLACK] = VALUE_ZERO;
  si->psq = SCORE_ZERO;
  si->checkersBB = attackers_to(square<KING>(sideToMove)) & pieces(~sideToMove);

  set_check_info(si);

  for (Bitboard b = pieces(); b; )
  {
      Square s = pop_lsb(&b);
      Piece pc = piece_on(s);
      si->key ^= Zobrist::psq[pc][s];
      si->psq += PSQT::psq[pc][s];
  }

  if (si->epSquare != SQ_NONE)
      si->key ^= Zobrist::enpassant[file_of(si->epSquare)];

  if (sideToMove == BLACK)
      si->key ^= Zobrist::side;

  si->key ^= Zobrist::castling[si->castlingRights];

  for (Bitboard b = pieces(PAWN); b; )
  {
      Square s = pop_lsb(&b);
      si->pawnKey ^= Zobrist::psq[piece_on(s)][s];
  }

  for (Piece pc : Pieces)
  {
      if (type_of(pc) != PAWN && type_of(pc) != KING)
          si->nonPawnMaterial[color_of(pc)] += pieceCount[pc] * PieceValue[MG][pc];

      for (int cnt = 0; cnt < pieceCount[pc]; ++cnt)
          si->materialKey ^= Zobrist::psq[pc][cnt];
  }
}


/// Position::set() is an overload to initialize the position object with
/// the given endgame code string like "KBPKN". It is mainly a helper to
/// get the material key out of an endgame code.

Position& Position::set(const string& code, Color c, StateInfo* si) {

  assert(code.length() > 0 && code.length() < 8);
  assert(code[0] == 'K');

  string sides[] = { code.substr(code.find('K', 1)),      // Weak
                     code.substr(0, code.find('K', 1)) }; // Strong

  std::transform(sides[c].begin(), sides[c].end(), sides[c].begin(), tolower);

  string fenStr = "8/" + sides[0] + char(8 - sides[0].length() + '0') + "/8/8/8/8/"
                       + sides[1] + char(8 - sides[1].length() + '0') + "/8 w - - 0 10";

  return set(fenStr, false, si, nullptr);
}


/// Position::fen() returns a FEN representation of the position. In case of
/// Chess960 the Shredder-FEN notation is used. This is mainly a debugging function.

const string Position::fen() const {

  int emptyCnt;
  std::ostringstream ss;

  for (Rank r = RANK_8; r >= RANK_1; --r)
  {
      for (File f = FILE_A; f <= FILE_H; ++f)
      {
          for (emptyCnt = 0; f <= FILE_H && empty(make_square(f, r)); ++f)
              ++emptyCnt;

          if (emptyCnt)
              ss << emptyCnt;

          if (f <= FILE_H)
              ss << PieceToChar[piece_on(make_square(f, r))];
      }

      if (r > RANK_1)
          ss << '/';
  }

  ss << (sideToMove == WHITE ? " w " : " b ");

  if (can_castle(WHITE_OO))
      ss << (chess960 ? char('A' + file_of(castling_rook_square(WHITE |  KING_SIDE))) : 'K');

  if (can_castle(WHITE_OOO))
      ss << (chess960 ? char('A' + file_of(castling_rook_square(WHITE | QUEEN_SIDE))) : 'Q');

  if (can_castle(BLACK_OO))
      ss << (chess960 ? char('a' + file_of(castling_rook_square(BLACK |  KING_SIDE))) : 'k');

  if (can_castle(BLACK_OOO))
      ss << (chess960 ? char('a' + file_of(castling_rook_square(BLACK | QUEEN_SIDE))) : 'q');

  if (!can_castle(WHITE) && !can_castle(BLACK))
      ss << '-';

  ss << (ep_square() == SQ_NONE ? " - " : " " + UCI::square(ep_square()) + " ")
     << st->rule50 << " " << 1 + (gamePly - (sideToMove == BLACK)) / 2;

  return ss.str();
}


/// Position::slider_blockers() returns a bitboard of all the pieces (both colors)
/// that are blocking attacks on the square 's' from 'sliders'. A piece blocks a
/// slider if removing that piece from the board would result in a position where
/// square 's' is attacked. For example, a king-attack blocking piece can be either
/// a pinned or a discovered check piece, according if its color is the opposite
/// or the same of the color of the slider.

Bitboard Position::slider_blockers(Bitboard sliders, Square s, Bitboard& pinners) const {

  Bitboard blockers = 0;
  pinners = 0;

  // Snipers are sliders that attack 's' when a piece is removed
  Bitboard snipers = (  (PseudoAttacks[  ROOK][s] & pieces(QUEEN, ROOK))
                      | (PseudoAttacks[BISHOP][s] & pieces(QUEEN, BISHOP))) & sliders;

  while (snipers)
  {
    Square sniperSq = pop_lsb(&snipers);
    Bitboard b = between_bb(s, sniperSq) & pieces();

    if (b && !more_than_one(b))
    {
        blockers |= b;
        if (b & pieces(color_of(piece_on(s))))
            pinners |= sniperSq;
    }
  }
  return blockers;
}


/// Position::attackers_to() computes a bitboard of all pieces which attack a
/// given square. Slider attacks use the occupied bitboard to indicate occupancy.

Bitboard Position::attackers_to(Square s, Bitboard occupied) const {

  return  (attacks_from<PAWN>(s, BLACK)    & pieces(WHITE, PAWN))
        | (attacks_from<PAWN>(s, WHITE)    & pieces(BLACK, PAWN))
        | (attacks_from<KNIGHT>(s)         & pieces(KNIGHT))
        | (attacks_bb<  ROOK>(s, occupied) & pieces(  ROOK, QUEEN))
        | (attacks_bb<BISHOP>(s, occupied) & pieces(BISHOP, QUEEN))
        | (attacks_from<KING>(s)           & pieces(KING));
}


/// Position::legal() tests whether a pseudo-legal move is legal

bool Position::legal(Move m) const {

  assert(is_ok(m));

  Color us = sideToMove;
  Square from = from_sq(m);

  assert(color_of(moved_piece(m)) == us);
  assert(piece_on(square<KING>(us)) == make_piece(us, KING));

  // En passant captures are a tricky special case. Because they are rather
  // uncommon, we do it simply by testing whether the king is attacked after
  // the move is made.
  if (type_of(m) == ENPASSANT)
  {
      Square ksq = square<KING>(us);
      Square to = to_sq(m);
      Square capsq = to - pawn_push(us);
      Bitboard occupied = (pieces() ^ from ^ capsq) | to;

      assert(to == ep_square());
      assert(moved_piece(m) == make_piece(us, PAWN));
      assert(piece_on(capsq) == make_piece(~us, PAWN));
      assert(piece_on(to) == NO_PIECE);

      return   !(attacks_bb<  ROOK>(ksq, occupied) & pieces(~us, QUEEN, ROOK))
            && !(attacks_bb<BISHOP>(ksq, occupied) & pieces(~us, QUEEN, BISHOP));
  }

  // If the moving piece is a king, check whether the destination
  // square is attacked by the opponent. Castling moves are checked
  // for legality during move generation.
  if (type_of(piece_on(from)) == KING)
      return type_of(m) == CASTLING || !(attackers_to(to_sq(m)) & pieces(~us));

  // A non-king move is legal if and only if it is not pinned or it
  // is moving along the ray towards or away from the king.
  return   !(blockers_for_king(us) & from)
        ||  aligned(from, to_sq(m), square<KING>(us));
}


/// Position::pseudo_legal() takes a random move and tests whether the move is
/// pseudo legal. It is used to validate moves from TT that can be corrupted
/// due to SMP concurrent access or hash position key aliasing.

bool Position::pseudo_legal(const Move m) const {

  Color us = sideToMove;
  Square from = from_sq(m);
  Square to = to_sq(m);
  Piece pc = moved_piece(m);

  // Use a slower but simpler function for uncommon cases
  if (type_of(m) != NORMAL)
      return MoveList<LEGAL>(*this).contains(m);

  // Is not a promotion, so promotion piece must be empty
  if (promotion_type(m) - KNIGHT != NO_PIECE_TYPE)
      return false;

  // If the 'from' square is not occupied by a piece belonging to the side to
  // move, the move is obviously not legal.
  if (pc == NO_PIECE || color_of(pc) != us)
      return false;

  // The destination square cannot be occupied by a friendly piece
  if (pieces(us) & to)
      return false;

  // Handle the special case of a pawn move
  if (type_of(pc) == PAWN)
  {
      // We have already handled promotion moves, so destination
      // cannot be on the 8th/1st rank.
      if (rank_of(to) == relative_rank(us, RANK_8))
          return false;

      if (   !(attacks_from<PAWN>(from, us) & pieces(~us) & to) // Not a capture
          && !((from + pawn_push(us) == to) && empty(to))       // Not a single push
          && !(   (from + 2 * pawn_push(us) == to)              // Not a double push
               && (rank_of(from) == relative_rank(us, RANK_2))
               && empty(to)
               && empty(to - pawn_push(us))))
          return false;
  }
  else if (!(attacks_from(type_of(pc), from) & to))
      return false;

  // Evasions generator already takes care to avoid some kind of illegal moves
  // and legal() relies on this. We therefore have to take care that the same
  // kind of moves are filtered out here.
  if (checkers())
  {
      if (type_of(pc) != KING)
      {
          // Double check? In this case a king move is required
          if (more_than_one(checkers()))
              return false;

          // Our move must be a blocking evasion or a capture of the checking piece
          if (!((between_bb(lsb(checkers()), square<KING>(us)) | checkers()) & to))
              return false;
      }
      // In case of king moves under check we have to remove king so as to catch
      // invalid moves like b1a1 when opposite queen is on c1.
      else if (attackers_to(to, pieces() ^ from) & pieces(~us))
          return false;
  }

  return true;
}


/// Position::gives_check() tests whether a pseudo-legal move gives a check

bool Position::gives_check(Move m) const {

  assert(is_ok(m));
  assert(color_of(moved_piece(m)) == sideToMove);

  Square from = from_sq(m);
  Square to = to_sq(m);

  // Is there a direct check?
  if (st->checkSquares[type_of(piece_on(from))] & to)
      return true;

  // Is there a discovered check?
  if (   (st->blockersForKing[~sideToMove] & from)
      && !aligned(from, to, square<KING>(~sideToMove)))
      return true;

  switch (type_of(m))
  {
  case NORMAL:
      return false;

  case PROMOTION:
      return attacks_bb(promotion_type(m), to, pieces() ^ from) & square<KING>(~sideToMove);

  // En passant capture with check? We have already handled the case
  // of direct checks and ordinary discovered check, so the only case we
  // need to handle is the unusual case of a discovered check through
  // the captured pawn.
  case ENPASSANT:
  {
      Square capsq = make_square(file_of(to), rank_of(from));
      Bitboard b = (pieces() ^ from ^ capsq) | to;

      return  (attacks_bb<  ROOK>(square<KING>(~sideToMove), b) & pieces(sideToMove, QUEEN, ROOK))
            | (attacks_bb<BISHOP>(square<KING>(~sideToMove), b) & pieces(sideToMove, QUEEN, BISHOP));
  }
  case CASTLING:
  {
      Square kfrom = from;
      Square rfrom = to; // Castling is encoded as 'King captures the rook'
      Square kto = relative_square(sideToMove, rfrom > kfrom ? SQ_G1 : SQ_C1);
      Square rto = relative_square(sideToMove, rfrom > kfrom ? SQ_F1 : SQ_D1);

      return   (PseudoAttacks[ROOK][rto] & square<KING>(~sideToMove))
            && (attacks_bb<ROOK>(rto, (pieces() ^ kfrom ^ rfrom) | rto | kto) & square<KING>(~sideToMove));
  }
  default:
      assert(false);
      return false;
  }
}


/// Position::do_move() makes a move, and saves all information necessary
/// to a StateInfo object. The move is assumed to be legal. Pseudo-legal
/// moves should be filtered out before this function is called.

void Position::do_move(Move m, StateInfo& newSt, bool givesCheck) {

  assert(is_ok(m));
  assert(&newSt != st);

  thisThread->nodes.fetch_add(1, std::memory_order_relaxed);
  Key k = st->key ^ Zobrist::side;

  // Copy some fields of the old state to our new StateInfo object except the
  // ones which are going to be recalculated from scratch anyway and then switch
  // our state pointer to point to the new (ready to be updated) state.
  std::memcpy(&newSt, st, offsetof(StateInfo, key));
  newSt.previous = st;
  st = &newSt;

  // Increment ply counters. In particular, rule50 will be reset to zero later on
  // in case of a capture or a pawn move.
  ++gamePly;
  ++st->rule50;
  ++st->pliesFromNull;

  Color us = sideToMove;
  Color them = ~us;
  Square from = from_sq(m);
  Square to = to_sq(m);
  Piece pc = piece_on(from);
  Piece captured = type_of(m) == ENPASSANT ? make_piece(them, PAWN) : piece_on(to);

  assert(color_of(pc) == us);
  assert(captured == NO_PIECE || color_of(captured) == (type_of(m) != CASTLING ? them : us));
  assert(type_of(captured) != KING);

  if (type_of(m) == CASTLING)
  {
      assert(pc == make_piece(us, KING));
      assert(captured == make_piece(us, ROOK));

      Square rfrom, rto;
      do_castling<true>(us, from, to, rfrom, rto);

      st->psq += PSQT::psq[captured][rto] - PSQT::psq[captured][rfrom];
      k ^= Zobrist::psq[captured][rfrom] ^ Zobrist::psq[captured][rto];
      captured = NO_PIECE;
  }

  if (captured)
  {
      Square capsq = to;

      // If the captured piece is a pawn, update pawn hash key, otherwise
      // update non-pawn material.
      if (type_of(captured) == PAWN)
      {
          if (type_of(m) == ENPASSANT)
          {
              capsq -= pawn_push(us);

              assert(pc == make_piece(us, PAWN));
              assert(to == st->epSquare);
              assert(relative_rank(us, to) == RANK_6);
              assert(piece_on(to) == NO_PIECE);
              assert(piece_on(capsq) == make_piece(them, PAWN));

              board[capsq] = NO_PIECE; // Not done by remove_piece()
          }

          st->pawnKey ^= Zobrist::psq[captured][capsq];
      }
      else
          st->nonPawnMaterial[them] -= PieceValue[MG][captured];

      // Update board and piece lists
      remove_piece(captured, capsq);

      // Update material hash key and prefetch access to materialTable
      k ^= Zobrist::psq[captured][capsq];
      st->materialKey ^= Zobrist::psq[captured][pieceCount[captured]];
      prefetch(thisThread->materialTable[st->materialKey]);

      // Update incremental scores
      st->psq -= PSQT::psq[captured][capsq];

      // Reset rule 50 counter
      st->rule50 = 0;
  }

  // Update hash key
  k ^= Zobrist::psq[pc][from] ^ Zobrist::psq[pc][to];

  // Reset en passant square
  if (st->epSquare != SQ_NONE)
  {
      k ^= Zobrist::enpassant[file_of(st->epSquare)];
      st->epSquare = SQ_NONE;
  }

  // Update castling rights if needed
  if (st->castlingRights && (castlingRightsMask[from] | castlingRightsMask[to]))
  {
      int cr = castlingRightsMask[from] | castlingRightsMask[to];
      k ^= Zobrist::castling[st->castlingRights & cr];
      st->castlingRights &= ~cr;
  }

  // Move the piece. The tricky Chess960 castling is handled earlier
  if (type_of(m) != CASTLING)
      move_piece(pc, from, to);

  // If the moving piece is a pawn do some special extra work
  if (type_of(pc) == PAWN)
  {
      // Set en-passant square if the moved pawn can be captured
      if (   (int(to) ^ int(from)) == 16
          && (attacks_from<PAWN>(to - pawn_push(us), us) & pieces(them, PAWN)))
      {
          st->epSquare = to - pawn_push(us);
          k ^= Zobrist::enpassant[file_of(st->epSquare)];
      }

      else if (type_of(m) == PROMOTION)
      {
          Piece promotion = make_piece(us, promotion_type(m));

          assert(relative_rank(us, to) == RANK_8);
          assert(type_of(promotion) >= KNIGHT && type_of(promotion) <= QUEEN);

          remove_piece(pc, to);
          put_piece(promotion, to);

          // Update hash keys
          k ^= Zobrist::psq[pc][to] ^ Zobrist::psq[promotion][to];
          st->pawnKey ^= Zobrist::psq[pc][to];
          st->materialKey ^=  Zobrist::psq[promotion][pieceCount[promotion]-1]
                            ^ Zobrist::psq[pc][pieceCount[pc]];

          // Update incremental score
          st->psq += PSQT::psq[promotion][to] - PSQT::psq[pc][to];

          // Update material
          st->nonPawnMaterial[us] += PieceValue[MG][promotion];
      }

      // Update pawn hash key and prefetch access to pawnsTable
      st->pawnKey ^= Zobrist::psq[pc][from] ^ Zobrist::psq[pc][to];
      prefetch2(thisThread->pawnsTable[st->pawnKey]);

      // Reset rule 50 draw counter
      st->rule50 = 0;
  }

  // Update incremental scores
  st->psq += PSQT::psq[pc][to] - PSQT::psq[pc][from];

  // Set capture piece
  st->capturedPiece = captured;

  // Update the key with the final value
  st->key = k;

  // Calculate checkers bitboard (if move gives check)
  st->checkersBB = givesCheck ? attackers_to(square<KING>(them)) & pieces(us) : 0;

  sideToMove = ~sideToMove;

  // Update king attacks used for fast check detection
  set_check_info(st);

  assert(pos_is_ok());
}


/// Position::undo_move() unmakes a move. When it returns, the position should
/// be restored to exactly the same state as before the move was made.

void Position::undo_move(Move m) {

  assert(is_ok(m));

  sideToMove = ~sideToMove;

  Color us = sideToMove;
  Square from = from_sq(m);
  Square to = to_sq(m);
  Piece pc = piece_on(to);

  assert(empty(from) || type_of(m) == CASTLING);
  assert(type_of(st->capturedPiece) != KING);

  if (type_of(m) == PROMOTION)
  {
      assert(relative_rank(us, to) == RANK_8);
      assert(type_of(pc) == promotion_type(m));
      assert(type_of(pc) >= KNIGHT && type_of(pc) <= QUEEN);

      remove_piece(pc, to);
      pc = make_piece(us, PAWN);
      put_piece(pc, to);
  }

  if (type_of(m) == CASTLING)
  {
      Square rfrom, rto;
      do_castling<false>(us, from, to, rfrom, rto);
  }
  else
  {
      move_piece(pc, to, from); // Put the piece back at the source square

      if (st->capturedPiece)
      {
          Square capsq = to;

          if (type_of(m) == ENPASSANT)
          {
              capsq -= pawn_push(us);

              assert(type_of(pc) == PAWN);
              assert(to == st->previous->epSquare);
              assert(relative_rank(us, to) == RANK_6);
              assert(piece_on(capsq) == NO_PIECE);
              assert(st->capturedPiece == make_piece(~us, PAWN));
          }

          put_piece(st->capturedPiece, capsq); // Restore the captured piece
      }
  }

  // Finally point our state pointer back to the previous state
  st = st->previous;
  --gamePly;

  assert(pos_is_ok());
}


/// Position::do_castling() is a helper used to do/undo a castling move. This
/// is a bit tricky in Chess960 where from/to squares can overlap.
template<bool Do>
void Position::do_castling(Color us, Square from, Square& to, Square& rfrom, Square& rto) {

  bool kingSide = to > from;
  rfrom = to; // Castling is encoded as "king captures friendly rook"
  rto = relative_square(us, kingSide ? SQ_F1 : SQ_D1);
  to = relative_square(us, kingSide ? SQ_G1 : SQ_C1);

  // Remove both pieces first since squares could overlap in Chess960
  remove_piece(make_piece(us, KING), Do ? from : to);
  remove_piece(make_piece(us, ROOK), Do ? rfrom : rto);
  board[Do ? from : to] = board[Do ? rfrom : rto] = NO_PIECE; // Since remove_piece doesn't do it for us
  put_piece(make_piece(us, KING), Do ? to : from);
  put_piece(make_piece(us, ROOK), Do ? rto : rfrom);
}


/// Position::do(undo)_null_move() is used to do(undo) a "null move": It flips
/// the side to move without executing any move on the board.

void Position::do_null_move(StateInfo& newSt) {

  assert(!checkers());
  assert(&newSt != st);

  std::memcpy(&newSt, st, sizeof(StateInfo));
  newSt.previous = st;
  st = &newSt;

  if (st->epSquare != SQ_NONE)
  {
      st->key ^= Zobrist::enpassant[file_of(st->epSquare)];
      st->epSquare = SQ_NONE;
  }

  st->key ^= Zobrist::side;
  prefetch(TT.first_entry(st->key));

  ++st->rule50;
  st->pliesFromNull = 0;

  sideToMove = ~sideToMove;

  set_check_info(st);

  assert(pos_is_ok());
}

void Position::undo_null_move() {

  assert(!checkers());

  st = st->previous;
  sideToMove = ~sideToMove;
}


/// Position::key_after() computes the new hash key after the given move. Needed
/// for speculative prefetch. It doesn't recognize special moves like castling,
/// en-passant and promotions.

Key Position::key_after(Move m) const {

  Square from = from_sq(m);
  Square to = to_sq(m);
  Piece pc = piece_on(from);
  Piece captured = piece_on(to);
  Key k = st->key ^ Zobrist::side;

  if (captured)
      k ^= Zobrist::psq[captured][to];

  return k ^ Zobrist::psq[pc][to] ^ Zobrist::psq[pc][from];
}


/// Position::see_ge (Static Exchange Evaluation Greater or Equal) tests if the
/// SEE value of move is greater or equal to the given threshold. We'll use an
/// algorithm similar to alpha-beta pruning with a null window.

bool Position::see_ge(Move m, Value threshold) const {

  assert(is_ok(m));

  // Only deal with normal moves, assume others pass a simple see
  if (type_of(m) != NORMAL)
      return VALUE_ZERO >= threshold;

  Bitboard stmAttackers;
  Square from = from_sq(m), to = to_sq(m);
  PieceType nextVictim = type_of(piece_on(from));
  Color us = color_of(piece_on(from));
  Color stm = ~us; // First consider opponent's move
  Value balance;   // Values of the pieces taken by us minus opponent's ones

  // The opponent may be able to recapture so this is the best result
  // we can hope for.
  balance = PieceValue[MG][piece_on(to)] - threshold;

  if (balance < VALUE_ZERO)
      return false;

  // Now assume the worst possible result: that the opponent can
  // capture our piece for free.
  balance -= PieceValue[MG][nextVictim];

  // If it is enough (like in PxQ) then return immediately. Note that
  // in case nextVictim == KING we always return here, this is ok
  // if the given move is legal.
  if (balance >= VALUE_ZERO)
      return true;

  // Find all attackers to the destination square, with the moving piece
  // removed, but possibly an X-ray attacker added behind it.
  Bitboard occupied = pieces() ^ from ^ to;
  Bitboard attackers = attackers_to(to, occupied) & occupied;

  while (true)
  {
      stmAttackers = attackers & pieces(stm);

      // Don't allow pinned pieces to attack (except the king) as long as
      // all pinners are on their original square.
      if (!(st->pinnersForKing[stm] & ~occupied))
          stmAttackers &= ~st->blockersForKing[stm];

      // If stm has no more attackers then give up: stm loses
      if (!stmAttackers)
          break;

      // Locate and remove the next least valuable attacker, and add to
      // the bitboard 'attackers' the possibly X-ray attackers behind it.
      nextVictim = min_attacker<PAWN>(byTypeBB, to, stmAttackers, occupied, attackers);

      stm = ~stm; // Switch side to move

      // Negamax the balance with alpha = balance, beta = balance+1 and
      // add nextVictim's value.
      //
      //      (balance, balance+1) -> (-balance-1, -balance)
      //
      assert(balance < VALUE_ZERO);

      balance = -balance - 1 - PieceValue[MG][nextVictim];

      // If balance is still non-negative after giving away nextVictim then we
      // win. The only thing to be careful about it is that we should revert
      // stm if we captured with the king when the opponent still has attackers.
      if (balance >= VALUE_ZERO)
      {
          if (nextVictim == KING && (attackers & pieces(stm)))
              stm = ~stm;
          break;
      }
      assert(nextVictim != KING);
  }
  return us != stm; // We break the above loop when stm loses
}


/// Position::is_draw() tests whether the position is drawn by 50-move rule
/// or by repetition. It does not detect stalemates.

bool Position::is_draw(int ply) const {

  if (st->rule50 > 99 && (!checkers() || MoveList<LEGAL>(*this).size()))
      return true;

  int end = std::min(st->rule50, st->pliesFromNull);

  if (end < 4)
    return false;

  StateInfo* stp = st->previous->previous;
  int cnt = 0;

  for (int i = 4; i <= end; i += 2)
  {
      stp = stp->previous->previous;

      // Return a draw score if a position repeats once earlier but strictly
      // after the root, or repeats twice before or at the root.
      if (   stp->key == st->key
          && ++cnt + (ply > i) == 2)
          return true;
  }

  return false;
}


/// Position::flip() flips position with the white and black sides reversed. This
/// is only useful for debugging e.g. for finding evaluation symmetry bugs.

void Position::flip() {

  string f, token;
  std::stringstream ss(fen());

  for (Rank r = RANK_8; r >= RANK_1; --r) // Piece placement
  {
      std::getline(ss, token, r > RANK_1 ? '/' : ' ');
      f.insert(0, token + (f.empty() ? " " : "/"));
  }

  ss >> token; // Active color
  f += (token == "w" ? "B " : "W "); // Will be lowercased later

  ss >> token; // Castling availability
  f += token + " ";

  std::transform(f.begin(), f.end(), f.begin(),
                 [](char c) { return char(islower(c) ? toupper(c) : tolower(c)); });

  ss >> token; // En passant square
  f += (token == "-" ? token : token.replace(1, 1, token[1] == '3' ? "6" : "3"));

  std::getline(ss, token); // Half and full moves
  f += token;

  set(f, is_chess960(), st, this_thread());

  assert(pos_is_ok());
}


/// Position::pos_is_ok() performs some consistency checks for the
/// position object and raises an asserts if something wrong is detected.
/// This is meant to be helpful when debugging.

bool Position::pos_is_ok() const {

  const bool Fast = true; // Quick (default) or full check?

  if (   (sideToMove != WHITE && sideToMove != BLACK)
      || piece_on(square<KING>(WHITE)) != W_KING
      || piece_on(square<KING>(BLACK)) != B_KING
      || (   ep_square() != SQ_NONE
          && relative_rank(sideToMove, ep_square()) != RANK_6))
      assert(0 && "pos_is_ok: Default");

  if (Fast)
      return true;

  if (   pieceCount[W_KING] != 1
      || pieceCount[B_KING] != 1
      || attackers_to(square<KING>(~sideToMove)) & pieces(sideToMove))
      assert(0 && "pos_is_ok: Kings");

  if (   (pieces(PAWN) & (Rank1BB | Rank8BB))
      || pieceCount[W_PAWN] > 8
      || pieceCount[B_PAWN] > 8)
      assert(0 && "pos_is_ok: Pawns");

  if (   (pieces(WHITE) & pieces(BLACK))
      || (pieces(WHITE) | pieces(BLACK)) != pieces()
      || popcount(pieces(WHITE)) > 16
      || popcount(pieces(BLACK)) > 16)
      assert(0 && "pos_is_ok: Bitboards");

  for (PieceType p1 = PAWN; p1 <= KING; ++p1)
      for (PieceType p2 = PAWN; p2 <= KING; ++p2)
          if (p1 != p2 && (pieces(p1) & pieces(p2)))
              assert(0 && "pos_is_ok: Bitboards");

  StateInfo si = *st;
  set_state(&si);
  if (std::memcmp(&si, st, sizeof(StateInfo)))
      assert(0 && "pos_is_ok: State");

  for (Piece pc : Pieces)
  {
      if (   pieceCount[pc] != popcount(pieces(color_of(pc), type_of(pc)))
          || pieceCount[pc] != std::count(board, board + SQUARE_NB, pc))
          assert(0 && "pos_is_ok: Pieces");

      for (int i = 0; i < pieceCount[pc]; ++i)
          if (board[pieceList[pc][i]] != pc || index[pieceList[pc][i]] != i)
              assert(0 && "pos_is_ok: Index");
  }

  for (Color c = WHITE; c <= BLACK; ++c)
      for (CastlingSide s = KING_SIDE; s <= QUEEN_SIDE; s = CastlingSide(s + 1))
      {
          if (!can_castle(c | s))
              continue;

          if (   piece_on(castlingRookSquare[c | s]) != make_piece(c, ROOK)
              || castlingRightsMask[castlingRookSquare[c | s]] != (c | s)
              || (castlingRightsMask[square<KING>(c)] & (c | s)) != (c | s))
              assert(0 && "pos_is_ok: Castling");
      }

  return true;
}
